vjo.dsf.error.ErrorHandlerManager.register(new vjo.dsf.error.DefaultErrorHandler());
vjo.dsf.error.ErrorHandlerManager.enableOnError(true, false);
vjo.dsf.cookie.VjCookieJar.sCookieDomain = '.ebay.com';vjo.dsf.cookie.VjCookieJar.writeCookielet('ebay','js','1');
