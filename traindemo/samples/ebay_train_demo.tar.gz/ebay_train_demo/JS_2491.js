(function(){
(function() {
var Context = raptor.require('ebay.context.Context');
Context.call(Context,{"site":0,"errors":{"enabled":false},"app":"viewitem","domain":".ebay.com","cobrand":2,"pool":"production","locale":"en_US_MAIN","features":{},"pid":2047675});
})();

	if(typeof FastClick === 'function') {FastClick.attach(document.body);}
try {
	function warrantyCallInterceptor() {
		$.ajaxSetup({
        beforeSend: function(a, e) {
            try {
                var r = e && e.url && -1 != e.url.indexOf("/sc/add?") && -1 != e.url.indexOf("cart.payments");
                r && (e.url = e.url.replace("/cart.payments.", "/payments.").replace("/sc/add?", "/ws/eBayISAPI.dll?ShopCartProcessor&"))
            } catch (c) {}
        }
    });
  }
    $(document).ready(function() {
        $('.actPanel').on('click', '.serviceOption', function() {
          warrantyCallInterceptor();
        });
        $('#CenterPanel').on('mousedown', '#binBtn_btn', function() {
          if (($(".serviceOption").length > 0) && $(".serviceOption")[0].checked ){
            warrantyCallInterceptor();
          }
        });        
      	var url = window.location.href;
        if (url.indexOf("wbolp=1") >= 0) {
          url = url.replace("wbolp=1","warrantyRedirect=1");
          window.location.href = url;
        }
        if (url.indexOf("warrantyRedirect=1") >= 0) {
          warrantyCallInterceptor();
          if (($(".serviceOption").length > 0) && $(".serviceOption")[0].checked ){
            $("#binBtn_btn").click();
          }
        }
    });

} catch (e) {}

$(document).ready(function(){
	try {
$('#smtBackToAnchor').on('click', function(){var backToAnchor=$('.vi-VR-spl-lnk'); var url= backToAnchor.attr('href'); if(url.indexOf('http%3A%')!=-1) { url = decodeURIComponent(url); backToAnchor.attr('href',url); }});

var offset = $("#vi_snippetdesc_btn").offset();
if (offset){
	$(".vi-descsnpt-feedbacklnk").offset({ top: offset.top+10, left: offset.left+275});
}

		if (($("#paymentsPlaceHolderId").length <= 0) && ($(".si-sp-on-ebay").length > 0) ) {
			if ($("#ppcMsg .ppcDispMsg").length > 0) {
				$("#ret-accept").prepend('<div class="u-flL lable" id="paymentsPlaceHolderId" style="">Payments:</div><div class="u-flL rpColWid"><div id="payDet1" class=""><img class="pd-img" style="margin-right: 10px;" src="http://ir.ebaystatic.com/pictures/aw/pics/logos/logoPayPal_51x14.png" alt="PayPal" border="0"><span style="position:relative;"><img src="http://ir.ebaystatic.com/pictures/aw/pics/logos/CC_icons.png" alt="Visa/MasterCard, Amex, Discover" title="Visa/MasterCard, Amex, Discover" class="pd-pp-cc-container"><div class="vi-ppc-coffer-txt">Credit Cards processed by PayPal</div><div class="u-cb u-spcr-ht15"></div></span><div><img src="http://ir.ebaystatic.com/pictures/aw/pics/logos/logoPaypalCredit_104x16.png" class="pd-ppc-img" alt="PayPal Credit"></div><div class="vi-cc-exp-txt"></div><span><a rel="nofollow"></a><a id="vi-abf-payppc-lnkPH" aria-describedby="paymentsPlaceHolderId" href="#payCntId" class="vi-ds3-ter-a pd-lnk vi-payd-blk-lnk">See <b class="hideforacc">payment</b> details</a></span></div></div><div class="u-cb spcr"></div>');	
				$(".vi-cc-exp-txt").html($("#ppcMsg .ppcDispMsg").html());	
				$("#vi-abf-payppc-lnkPH").click(function(){		
					var tabId = ($("body.vi-deeplinksv2").length > 0) ? "#viTabs_0" : "#viTabs_1";
					var tabElem = $(tabId);
					if(tabElem.length>0){
						tabElem.trigger('click', ['noTabTracking']);
						trackingUtil("Payments_See_details_Iteminfo");
					}
					
				});			
			}
		}
	} catch (e) {}
});
 if(typeof GH!="undefined"&&GH){GH.urls={ autocomplete_js:"http://ir.ebaystatic.com/f/ol1e41pmee251bvjhybsauh5aaw.js",fnet_js:"https://c.paypal.com/webstatic/r/fb/fb-all-prod.akamai.pp2.min.js",ie8_js:"http://ir.ebaystatic.com/f/rbezfuzpu20wfd2kvejeb5adxyg.js",scandal_js:"http://ir.ebaystatic.com/f/wgp1j0iddmzdjjfgvr3dxrzz1i1.js" }; GH.GHSW={ raptor:"true",sandbox:0,emp:0,ac1:0,ac2:0,ac3:0,ac4:0,ac5:0,ac6:0,hideMobile:0,langSwitch:0,pool:0,ALERT_POPUPOFF:0,NEWALERT_POPUPOFF:0,newprofile:0,desktop_new_profile_service:"true" };} if(typeof GH!="undefined" && GH){GH_config={"siteId":"0","geoLang":"[]",sin:0,id:'',fn:'',pageId:2047675,selectedCatId:'11700',ct:0,tmx:''};GH.init();}var tabId = ($("body.vi-deeplinksv2").length > 0) ? "viTabs_0" : "viTabs_1";$("#e0").click(function(){try{$("#" + tabId)[0].trigger('click', ['noTabTracking']);}catch(e){$("#" + tabId).trigger('click', ['noTabTracking']);}trackingUtil("See_exclusions_itemInfo");});var tabId = ($("body.vi-deeplinksv2").length > 0) ? "viTabs_0" : "viTabs_1";$("#e1").click(function(){try{$("#" + tabId)[0].trigger('click', ['noTabTracking']);}catch(e){$("#" + tabId).trigger('click', ['noTabTracking']);}trackingUtil("See_exclusions_itemInfo");});
											var reltime = raptor.require("com.ebay.raptor.vi.RelativeEndTime");
											new reltime({dateAttr:"timeMs",dateElemSelector:"span.timeMs", endsTomorrowTerm:"Tomorrow", todayTerm:"Today", days:["Sunday", "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], AM:"AM", PM:"PM", is24HR:false, siteId:0, isEnded:true});							
										$("#e4").click(function(){var tabId = ($("body.vi-deeplinksv2").length > 0) ? "viTabs_0" : "viTabs_1";trackingUtil("Shipping_See_all_details_ItemSummary");try{$("#" + tabId)[0].trigger('click', ['noTabTracking']);}catch(e){$("#" + tabId).trigger('click', ['noTabTracking']);}});$("#expedited_link").click(function(){var tabId = ($("body.vi-deeplinksv2").length > 0) ? "viTabs_0" : "viTabs_1";trackingUtil("OneDayShipping_Link_in_Delivery_Expedited_Shipping");try{$("#" + tabId)[0].trigger('click', ['noTabTracking']);}catch(e){$("#" + tabId).trigger('click', ['noTabTracking']);}});$("#e5").click(function(){var tabId = ($("body.vi-deeplinksv2").length > 0) ? "viTabs_0" : "viTabs_1";trackingUtil("Calculate_link_ItemSummary");try{$("#" + tabId)[0].trigger('click', ['noTabTracking']);}catch(e){$("#" + tabId).trigger('click', ['noTabTracking']);}});
	var ia = raptor.require('com.ebay.raptor.vi.ItemAttributes');
	<!-- TODO: remove hardcoded ID -->
	new ia({readMoreId : 'readFull', hiddenContentId : 'hiddenContent'});

	$("#viTabs_0").bind('click', function(event, param) {		
		if(param !== 'noTabTracking') {
			trackingUtil("Description_Tab");
		}
	});

	$(".rpMainCont a").attr('target','_blank');	

	var tRtmPubsub = raptor.require('pubsub');
	if(tRtmPubsub) {
		tRtmPubsub.subscribe("ADD_TO_WATCH_TRIGGERED", function(msg){ $('body').trigger(("RTM_PUBLISH"),{'pids':(["280"])});});
	}
	
	var tRtmPubsub = raptor.require('pubsub');
	if(tRtmPubsub) {
		tRtmPubsub.subscribe("_SUBMIT_CARTBTN", function(msg){ $('body').trigger(("RTM_PUBLISH"),{'pids':(["20047"])});});
	}
	
	$("#_rtop").click(function(){		
		trackingUtil("Return_to_top");
	});
raptor.require('com.ebay.raptor.vi.cookie.ScreenDetail').init({"cookieName" : "dp1","cookieletName" : "pbf","currentResValue" : {"maxWidth":-1,"minWidth":-1,"name":"DEFAULT","value":0,"id":0,"integer":0},"resRange" : [{"maxWidth":-1,"minWidth":-1,"name":"DEFAULT","value":0,"id":0,"integer":0},{"maxWidth":1024,"minWidth":0,"name":"RES_1024","value":1,"id":1,"integer":1},{"maxWidth":1152,"minWidth":1025,"name":"RES_1152","value":2,"id":2,"integer":2},{"maxWidth":1280,"minWidth":1153,"name":"RES_1280","value":3,"id":3,"integer":3},{"maxWidth":1366,"minWidth":1281,"name":"RES_1366","value":4,"id":4,"integer":4},{"maxWidth":1440,"minWidth":1367,"name":"RES_1440","value":5,"id":5,"integer":5},{"maxWidth":1680,"minWidth":1441,"name":"RES_1680","value":6,"id":6,"integer":6},{"maxWidth":2147483647,"minWidth":1681,"name":"RES_MAX","value":7,"id":7,"integer":7}],"resBits" : [85,86,87],"currentViewportValue" : {"maxWidth":-1,"minWidth":-1,"name":"DEFAULT","value":0,"id":0,"integer":0},"viewportRange" : [{"maxWidth":-1,"minWidth":-1,"name":"DEFAULT","value":0,"id":0,"integer":0},{"maxWidth":1020,"minWidth":0,"name":"VIEWPORT_1","value":1,"id":1,"integer":1},{"maxWidth":1024,"minWidth":1021,"name":"VIEWPORT_2","value":2,"id":2,"integer":2},{"maxWidth":1148,"minWidth":1025,"name":"VIEWPORT_3","value":3,"id":3,"integer":3},{"maxWidth":1152,"minWidth":1149,"name":"VIEWPORT_4","value":4,"id":4,"integer":4},{"maxWidth":1276,"minWidth":1153,"name":"VIEWPORT_5","value":5,"id":5,"integer":5},{"maxWidth":1280,"minWidth":1277,"name":"VIEWPORT_6","value":6,"id":6,"integer":6},{"maxWidth":2147483647,"minWidth":1281,"name":"VIEWPORT_7","value":7,"id":7,"integer":7}],"viewportBits" : [69,70,71]});
	raptor.require('com.ebay.raptor.vi.tracking.SitespeedTimers').init({"itemId" : "191845238561"});
$rwidgets(['com.ebay.raptor.vi.isum.smartBackTo','w1-1',{"smtBackToAnchorArrowId":"smtBackToAnchorArrow","smtBackToAnchorId":"smtBackToAnchor","numLevels":1,"isBacktoSearch":false},0,0,0,['ui.InlineFeedbackLink','w1-2']],['com.ebay.raptor.vi.topmessagepanel.TopMessagePanel','w1-3',{"CHINESE_BUYER_HIGH_BIDDER_PC_ON":"You're the highest bidder. ","CHINESE_BUYER_HIGH_BIDDER_RESERVE_NOT_MET_PC_ON":"You're the highest bidder but the reserve price has not been met. ","CHINESE_BUYER_OUTBIDDER_PC_ON":"You've been outbid. ","smId":"w1-3-_msg","dummy":"##n##","inlineExp":false,"autoRefreshSvcId":"AUTO_REFRESH_SVC","panelId":"msgPanel"}],['ui.Overlay','w1-4',{"ariaLable":"Delivery help overlay is opened.","position":"pointer","id":"imprtoly","pointerType":"horizontal","trigger":"imprthlp","closeOnBodyClick":true,"accessible":true,"enableAutoFocus":true,"closeTitle":"Close button. This closes the delivery help overlay.","ariaDesc":"You are inside the delivery help overlay.","hasCloseButton":true}],['ui.Overlay','w1-5',{"ariaLable":"Delivery help overlay is opened.","position":"pointer","id":"w1-5-overlay","pointerType":"horizontal","trigger":"hldhlp","closeOnBodyClick":true,"accessible":true,"enableAutoFocus":true,"closeTitle":"Close button. This closes the delivery help overlay.","ariaDesc":"You are inside the delivery help overlay.","hasCloseButton":true}],['ebay.viewItem.PicturePanel','w1-6',{"id":"vi_pic_panel","fsImgList":[{"thumbImgUrl":"http:\u002F\u002Fi.ebayimg.com\u002Fimages\u002Fg\u002FXgwAAOSweW5VJtUo\u002Fs-l64.jpg","thumbImgSize":null,"displayImgUrl":"http:\u002F\u002Fi.ebayimg.com\u002Fimages\u002Fg\u002FXgwAAOSweW5VJtUo\u002Fs-l300.jpg","displayImgSize":null,"maxImageUrl":"http:\u002F\u002Fi.ebayimg.com\u002Fimages\u002Fg\u002FXgwAAOSweW5VJtUo\u002Fs-l1600.jpg","maxImageHeight":515,"maxImageWidth":515,"zoomEnabled":false,"enlargeEnabled":true}]}],['com.ebay.raptor.vi.share.ShareLinks','w1-7',{"shareJsElmId":"ebay-scShare","widgetType":"SHARE","isProdEnv":true,"canonicalurl":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fkohler-gp21087-cp-trend-tub-and-shower-handle-free-shipping-\u002F191845238561","plaModel":{"printLink":"http:\u002F\u002Fcgi.ebay.com\u002Fws\u002FeBayISAPI.dll?ViewItem&category=42024&item=191845238561&rt=nc&print=all&si=%2BjzGOxLj3cE2MJfDWBwDhZLNR7U%3D","reportLink":"http:\u002F\u002Fcgi1.ebay.com\u002Fws\u002FeBayISAPI.dll?ReportThisItemRedirect&active=0&rt=nc&_trksid=p2047675.l2566&itemid=191845238561&seller=hockeykevin1999","socialSignalsJsUrl":"http:\u002F\u002Fir.ebaystatic.com\u002Fz\u002Fe3\u002Faluc3n21uq55vlxq0m22rohx0.js","shareWidgetJsUrl":"http:\u002F\u002Fir.ebaystatic.com\u002Frs\u002Fv\u002F2gej3litva2onbjtfffiymiare0.js","canonicalUrl":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fkohler-gp21087-cp-trend-tub-and-shower-handle-free-shipping-\u002F191845238561","breadCrumbLeafCategories":"11700,159907,20601,42024,","twitterMessage":"Check out Kohler GP21087-CP Trend Tub and Shower Handle FREE SHIPPING on @eBay","hashtags":null,"statusMessageOrder":null,"faceBookLikeButtonEnabled":true,"socialSignalsEnabled":false,"showTalkPopup":true,"key":"PageLevelActions"},"signalsJsElmId":"ebay-scjs"}],['com.ebay.raptor.vi.Description','w1-8',{"tgto":"http:\u002F\u002Fvi.vipr.ebaydesc.com","descSnippetEnabled":false,"logDescTimer":true}],['com.ebay.raptor.vi.bid.BidLayer','w1-9',{"svcId":"_OPN_PB_LAYER","invokeClkId":"_OPN_ONLOAD_PB_LAYER","openOnLoad":false,"overlayId":"w1-9-_olp"},0,0,0,['ui.Overlay','w1-10',{"ariaLable":"Bid layer is opened.","id":"w1-9-_olp","width":"470","accessible":true,"noFixedPos":true,"closeTitle":"Close button. This closes the bid layer.","modal":true,"hasCloseButton":true},'w1-9','w1-9-_olp',0,['com.ebay.raptor.vi.bid.placebid.PlaceBid','w1-11',{"INVALID_BIDAMOUNT_OF_HIGH_BIDDER":"w1-11-_invalidHighBid","HIGHBIDDER_1_MAX_BID_AWAY":"w1-11-_highBid1MaxBidAway","confirmBidTxt":"w1-11-_bidConfirmation","bidAgainURL":"http:\u002F\u002Foffer.ebay.com\u002Fws\u002FeBayISAPI.dll?MakeQuickBid&f=json&fromPage=2047675&item=191845238561&flow=bm&bidagain=true&isnullzero=true&mode=0","HIGHBIDDER_60_MIN_LEFT":"w1-11-_highBid60MinsLeft","disclaimerId":"w1-11-_disc","bidInitURL":"https:\u002F\u002Fsignin.ebay.com\u002Fws\u002FeBayISAPI.dll?SignIn&ru=http%3A%2F%2Fwww.ebay.com%2Fitm%2F191845238561%3Fbolp%3D1","lable":"_lbl","secondCharTxt":"w1-11-_s","minBidHBTxt":"w1-11-_minToBidHighBidder","inclVAT":"_invat","confirmBidURL":"http:\u002F\u002Foffer.ebay.com\u002Fws\u002FeBayISAPI.dll?MakeQuickBid&f=json&fromPage=2047675&uiid=954310453&item=191845238561&flow=bm&stok=-1856396378&mode=1","changeTxt":"w1-11-_change","wrapper":"_wrp","maxBidParamName":"maxbid","value":"_val","grayArea":"w1-11-_grey","impChBidTxtId":"w1-11-_impChBid","increaseBtnTxt":"w1-11-_increaseBtnTxt","LOW_BIDAMOUNT":"w1-11-_lowBid","resumeBidId":"w1-11-_resume","dayTxt":"w1-11-_day","placeBidTxt":"w1-11-_placeBid","lessTimeCss":"redTime  ","enterBidId":"w1-11-_enter","impChId":"w1-11-_impCh","DECSEP":"w1-11-_decsep","closeTxt":"w1-11-_close","svcId":"_OPN_PB_LAYER","bidBtnId":"w1-11-_place","nextStepId":"w1-11-_nextstep","placeBtnTxt":"w1-11-_placeBtnTxt","minBidTxt":"w1-11-_minToBid","detailLevelId":0,"dummy":"##1##","HIGHBIDDER_FIRST":"w1-11-_highBidFrst","BUYER_BLOCKED_NO_LINKED_PAYPAL_ACCOUNT":"w1-11-_noPaypal","calcImportChargeUrl":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fgetrates?item=191845238561&quantity=1&_trksid=p2047675.l2681","reviewBidId":"w1-11-_review","isRefreshOnClose":true,"statusMsgId":"w1-11-_statusMsg","currencyId":"w1-11-_currency","link":"_lnk","approxTxt":"w1-11-_approximately","hourTxt":"w1-11-_hour","INVALID_BIDAMOUNT":"w1-11-_invalidBid","counterStartSvcId":"COUNTER_START_SVC_ID","placeBidURL":"https:\u002F\u002Fsignin.ebay.com\u002Fws\u002FeBayISAPI.dll?SignIn&ru=http%3A%2F%2Fwww.ebay.com%2Fitm%2F191845238561%3Fbolp%3D1","approx":"_approx","btn":"_btn","reviewBidTxt":"w1-11-_reviewYourBid","loadingId":"w1-11-_loading","counterStopSvcId":"COUNTER_STOP_SVC_ID","BID_GREATER_THAN_BIN":"w1-11-_moreThanBin","defaultShpTxt":"w1-11-_shippingDefault","curBidId":"w1-11-_cur","hourCharTxt":"w1-11-_h","defaultImpChargeTxt":"w1-11-_impChargeDefault","minuteCharTxt":"w1-11-_m","timeLeftId":"w1-11-_timeLeft","min":"_min","cancelTxt":"w1-11-_cancel","HIGHBIDDER":"w1-11-_highBid","exclVAT":"_exvat","incMaxBidTxt":"w1-11-_increaseMaxBid","overlayId":"w1-9-_olp","refreshUrl":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fkohler-gp21087-cp-trend-tub-and-shower-handle-free-shipping-\u002F191845238561?hash=item2caade0721:g:xgwaaoswew5vjtuo&autorefresh=true","bidTitleId":"w1-11-_title","autoRefreshSvcId":"AUTO_REFRESH_SVC","dayCharTxt":"w1-11-_d","OUTBIDDER":"w1-11-_outBid","confirmBtnTxt":"w1-11-_confirmBtnTxt","counterSvcId":"COUNTER_SVC_ID","hoursTxt":"w1-11-_hours","HIGHBIDDER_RESERVE_NOT_MET":"w1-11-_highBidReserveNotMet","shippingId":"w1-11-_shp","freeShpTxt":"w1-11-_freeShipping","disclaimerGspId":"w1-11-_disc_gsp","yourMaxBidTxt":"w1-11-_yourMaximumBid"},'w1-10','w1-9-_cnt',0,['com.ebay.raptor.vi.StatusMsg','w1-12',{"message":"w1-12-_m","sizeClz":"smm-o ","smClz":"sm-o","outer":"w1-12-_o","isRefresh":false},'w1-11','w1-11-_statusMsg'],['com.ebay.raptor.vi.VIButton','w1-13',{"isCSS3":true,"mouseDownClass":"md","btnId":"w1-11-_place_btn"},'w1-11','w1-11-_place']]]],['com.ebay.raptor.vi.bid.BidLayer','w1-14',{"svcId":"w1-14-_oly","invokeClkId":"_OPN_ONLOAD_OCB_LAYER","openOnLoad":false,"overlayId":"w1-14-_olp"},0,0,0,['ui.Overlay','w1-15',{"ariaLable":"One click bid layer is opened.","id":"w1-14-_olp","width":"500","accessible":true,"enableAutoFocus":true,"noFixedPos":true,"closeTitle":"Close button. This closes the one click bid layer.","modal":true,"hasCloseButton":true,"draggable":true},'w1-14','w1-14-_olp',0,['com.ebay.raptor.vi.bid.oneclick.OneClickBid','w1-16',{"winningBidTxt":"w1-16-_win","secondTxt":"w1-16-_sec","disclaimerId":"w1-16-_disc","bidInitURL":"http:\u002F\u002Foffer.ebay.com\u002Fws\u002FeBayISAPI.dll?MakeQuickBid&f=json&fromPage=2047675&item=191845238561&flow=ocb&mode=0","lable":"_lbl","closeId":"w1-16-_cls","OUTBIDDER_STATUS":"w1-16-_out","wrapper":"_wrp","maxBidParamName":"maxbid","successClz":"sccs","value":"_val","HIGHBIDDER_STATUS":"w1-16-_high","minutesTxt":"w1-16-_mins","learnMoreId":"w1-16-_lrn","daysTxt":"w1-16-_day","MAKE_BID_ERROR_STATUS":"w1-16-_errmake","dayTxt":"w1-16-_day","olySvcId":"w1-14-_oly","startingBidTxt":"w1-16-_start","enterBidId":"w1-16-_enter","svcId":"_OPN_OCB_LAYER","closeTxt":"w1-16-_close","invokeClkId":"_OPN_ONLOAD_OCB_LAYER","bidBtnId":"w1-16-_ocb","bidURL":"http:\u002F\u002Foffer.ebay.com\u002Fws\u002FeBayISAPI.dll?MakeQuickBid&f=json&fromPage=2047675&uiid=954310453&item=191845238561&flow=ocb&stok=-1856396378&mode=1","openOnLoad":false,"minuteTxt":"w1-16-_min","dummy":"##1##","reviewBidId":"w1-16-_review","isRefreshOnClose":true,"statusMsgId":"w1-16-_statusMsg","AUCTION_ENDED_WINNER":"w1-16-_aewin","currencyId":"w1-16-_currency","hourTxt":"w1-16-_hour","approxTxt":"w1-16-_approximately","errorClz":"err","counterStartSvcId":"COUNTER_START_SVC_ID","approx":"_approx","btn":"_btn","secondsTxt":"w1-16-_secs","counterStopSvcId":"COUNTER_STOP_SVC_ID","curBidId":"w1-16-_cur","updateURL":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fws\u002FeBayISAPI.dll?ViewItemLite&item=191845238561&si=%2BjzGOxLj3cE2MJfDWBwDhZLNR7U%3D","warningClz":"wrng","timeLeftId":"w1-16-_timeLeft","MIN_BID_ERROR_STATUS":"w1-16-_errmin","detailLevel":6,"updateId":"w1-16-_updt","overlayId":"w1-14-_olp","AUCTION_ENDED_OUTBID":"w1-16-_aeout","refreshUrl":"http:\u002F\u002Fwww.ebay.com\u002Fitm\u002Fkohler-gp21087-cp-trend-tub-and-shower-handle-free-shipping-\u002F191845238561?hash=item2caade0721:g:xgwaaoswew5vjtuo&autorefresh=true","AUCTION_ENDED_RESERVE_NOT_MET":"w1-16-_aenrwin","autoRefreshSvcId":"AUTO_REFRESH_SVC","counterSvcId":"COUNTER_SVC_ID","hoursTxt":"w1-16-_hours","HIGH_BID_ERROR_STATUS":"w1-16-_errhigh","HIGHBIDDER_RESERVE_NOT_MET_STATUS":"w1-16-_highnr"},'w1-15','w1-14-_cnt',0,['com.ebay.raptor.vi.StatusMsg','w1-17',{"message":"w1-17-_m","sizeClz":"smi-o ","smClz":"sm-o","outer":"w1-17-_o","isRefresh":false},'w1-16','w1-16-_statusMsg'],['com.ebay.raptor.vi.VIButton','w1-18',{"isCSS3":true,"mouseDownClass":"md","btnId":"w1-16-_ocb_btn"},'w1-16','w1-16-_ocb']]]],['com.ebay.raptor.vi.isum.smartBackTo','w1-19',{"smtBackToAnchorId":"smtBackToAnchorBTF","showIcon":false,"isBacktoSearch":false}],['raptor.merch.MerchManager','w1-20',{"enableOnScroll":true,"pids":["100013","100035","100036","100037"],"customCallbackHandler":false,"loadJsAsync":false,"merchRaptorEnabled":true,"url":"http:\u002F\u002Fwww.ebay.com\u002Frec\u002Fplmt\u002F100013-100035-100036-100037?guid=ccb9a0291540a861d1b530bcfffafd6f&itm=191845238561&bWidth=1015&fmt=html&locale=en-US&usrSt=4&srchCtxt=%28dmLCat%3D-1%7CsrCnt%3D0%7CmCCatId%3D0%7CminPrice%3D-1.0%7CmaxPrice%3D-1.0%7CcrncyId%3D840%7CfShip%3D0%7Cetrs%3D0%29&usrSi=US&slr=61158074&ctg=42024&si=0&_qi=t6ulcpjqcj9%3Fjqpsobtlrbn%28%3E6%3B%3D3","th":1000}]);new (raptor.require('raptor.tracking.core.Tracker'))({"psi":"AuaApHRs*","rover":{"imp":"/roverimp/0/0/9","clk":"/roverclk/0/0/9","uri":"http://rover.ebay.com"},"pid":"p2047675"});raptor.require('raptor.tracking.idmap.IdMap').roverService("http://rover.ebay.com/idmap/0?footer");})();
			