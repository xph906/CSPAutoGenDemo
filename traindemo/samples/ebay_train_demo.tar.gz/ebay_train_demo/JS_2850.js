
	document.write ("<"+az+bz+cz+" type='text/javascript'"+dz+ez+catz+">");
	document.write("</"+az+bz+cz+">");
