
							function picOnLoad(isSetClkId){
								var elem = document.getElementById('icThrImg'); 
								var pic = document.getElementById('icImg'); 
								elem.style.display = 'none'; 
								pic.style.display = ''; 
								if(isSetClkId) {
									pic.setAttribute('clk', elem.getAttribute('imgsel'));	
								} 
								document.getElementById('imgNATxt').style.display = 'none';
								//document.getElementById('mainImgHldr').style.backgroundImage = 'none';
								return;
							}
							function picOnError(){
								var elemThr = document.getElementById('icThrImg');
								var pic = document.getElementById('icImg'); 
								elemThr.src='http://p.ebaystatic.com/aw/pics/cmp/icn/iconImgNA_96x96.gif'; 
								elemThr.style.display = ''; 
								pic.style.display = 'none'; 
								pic.setAttribute('clk', elemThr.getAttribute('imgsel')); 
								document.getElementById('imgNATxt').style.display = 'block';
								//document.getElementById('mainImgHldr').style.backgroundImage = 'none';					
								return;
							}
							var image = document.createElement('img');
							image.src=  'http://i.ebayimg.com/images/g/n1gAAOSwI3RW8qI7/s-l300.jpg';
							if(image.complete ||  image.readyState === 4){
								picTimer2=new Date().getTime();
								picOnLoad(true);
							}else{
							    image.onload = function(){ 
							    	picTimer1=new Date().getTime();
							    	picOnLoad(true);
							    };
							    image.onerror = function(){ 
									picOnError();	
								};
							}
							image.onerror = function(){ 
								picOnError();	
							};

							var backgroundImgTest = 'false';
							if (backgroundImgTest === 'true') {
								var bigImage = document.createElement('img');
								bigImage.src = '';		
							}
						