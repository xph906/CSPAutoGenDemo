
				var shElemntArry = getElementsByClassName(document.body,'sh-CostBB'); for(var i = shElemntArry.length - 1; i >= 0; --i){shElemntArry[i].style.display = 'none';shElemntArry[i].innerHTML = "+$49.95 shipping";}
				var shElemntArry = getElementsByClassName(document.body,'sh-CostBB-lkdhdr'); for(var i = shElemntArry.length - 1; i >= 0; --i){shElemntArry[i].style.display = 'inline';shElemntArry[i].innerHTML = "+$49.95 shipping";}
			