
					var shElemntArry = getElementsByClassName(document.body,'sh-CostBB');for(var i = shElemntArry.length - 1; i >= 0; --i){shElemntArry[i].style.display = 'none';}
					var shElemntArry = getElementsByClassName(document.body,'sh-CostBB-lkdhdr');for(var i = shElemntArry.length - 1; i >= 0; --i){shElemntArry[i].style.display = 'none';}
			