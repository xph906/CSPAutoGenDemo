
(function() {
var Context = raptor.require('ebay.context.Context');
Context.call(Context,{"site":0,"errors":{"enabled":false},"app":"storesweb","domain":".ebay.com","cobrand":2,"pool":"production","locale":"en_US_MAIN","features":{},"pid":2056350});
})();
 if(typeof GH!="undefined"&&GH){GH.urls={ autocomplete_js:"http://ir.ebaystatic.com/f/ol1e41pmee251bvjhybsauh5aaw.js",fnet_js:"https://c.paypal.com/webstatic/r/fb/fb-all-prod.akamai.pp2.min.js",ie8_js:"http://ir.ebaystatic.com/f/rbezfuzpu20wfd2kvejeb5adxyg.js",scandal_js:"http://ir.ebaystatic.com/f/wgp1j0iddmzdjjfgvr3dxrzz1i1.js" }; GH.GHSW={ raptor:"true",sandbox:0,emp:0,ac1:0,ac2:0,ac3:0,ac4:0,ac5:0,ac6:0,hideMobile:0,langSwitch:0,pool:0,ALERT_POPUPOFF:0,NEWALERT_POPUPOFF:0,newprofile:0,desktop_new_profile_service:"true" };} if(typeof GH!="undefined" && GH){GH_config={"siteId":"0","geoLang":"[]",sin:0,id:'',fn:'',pageId:2056350,ct:0};GH.init();}
(function(d){
	 var js, id = 'ebay-scShare';
	 if (d.getElementById(id)) {return;}
	 js = d.createElement('script');
	 js.id = id;
	 js.async = true; 
	 js.defer = true;
	 js.src = "http://ir.ebaystatic.com/z/24/cw2wv05nwayfjcfmvz305ijrt.js";
	 d.getElementsByTagName('head')[0].appendChild(js);
}(document));

		function RLogIdUtil() {
			var h = document.body.innerHTML;
			var idx = h.indexOf('<'+'!-- RcmdId');
			var h2 = h.substr(idx+5, 100);
			h2 = h2.substr(0, h2.indexOf('-'+'->'));
			//alert(h2);
			var a = h2.split(',');
			var rCmdId = '', rlogid = '';
			for (var i=0; i<a.length; i++) {
				var aa = a[i].split(' ');
				if (aa[0].indexOf('RcmdId') > -1) {
					rCmdId = aa[1];
				}
				if (aa[0].indexOf('RlogId') > -1) {
					rlogid = aa[1];
				}
			}
			//alert('rCmdId=' + rCmdId);
			//alert('rlogid=' + rlogid);
			
			var lnk = document.getElementById('__rlogLink');
			if (rlogid) {
				lnk.href = 'http://cal.vip.qa.ebay.com/cgi/logview?p_category=-&p_hour=18&p_impact=-&p_severity=-&p_month=8&p_day=9&p_logid=' + rlogid + '&p_cmd=show&p_year=2011&p_env=core_stagingsql'
			} else {
				lnk.innerHTML = '';
			}
		}
		RLogIdUtil();
	
	$("body").trigger("CONFIG_AJAX",{config:{containers:["#showDiagContainer"]}});

		var env = getEnvironment();
		var restBase = {};
		restBase[env] = "http://www.ebay.com/itm/layer";
	    new Lens({
	        "sid": "p2056350",
		    "restBase": restBase
	    });
	
		var eBayTREiasId = "nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wDk4SkAZWBqA+dj6x9nY+seQ==";
	
		var eBayTRInactive = "false";
	
		var eBayTRPageName = "Biographies &amp; Autobiographies";
	
		var eBayTRDisplayName = "My eBay Store - Listings";
	
		var eBayTRHomePage = "";
	
		var eBayTRStoreSearchTerm = "";
	
		var eBayTRItemId = "";
	
		var eBayTRItemTitle = "";
	
		var eBayTRListingFormat = "";
	
		var eBayTREvent = "";
	$rwidgets(['follow/widget','w1-1',{"csrf":"bbed1ac256ac0e64a7c8398bf19f3c749a7d8817dd5556b07b59f5a46d647f1a","moduleId":"2680","pageId":"2056350","entityId":"aboutagirl12312","entityType":"person","entityName":"Kitty Fane's Closet"}],['ui.Paging','w1-2',{"id":"pager","itemsOnPage":192,"totalCount":1,"currentPage":1,"totalPages":"1"}]);new (raptor.require('raptor.tracking.core.Tracker'))({"psi":"A01ToMYI*","rover":{"imp":"/roverimp/0/0/9","clk":"/roverclk/0/0/9","uri":"http://rover.ebay.com"},"pid":"p2056350"});raptor.require('raptor.tracking.idmap.IdMap').roverService("http://rover.ebay.com/idmap/0?footer");