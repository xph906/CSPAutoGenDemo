
	if ("ActiveXObject" in window) {
	    window.addEventListener('beforeunload', function() {
	        var iframeElements = Array.prototype.slice.call(document.getElementsByTagName('iframe'));
	        for (var i = 0, l = iframeElements.length; i < l; i++) {
	            iframeElements[i].parentNode.removeChild(iframeElements[i]);
	        }
	    });
	}
	