
		(function(d) {
			var js, id = 'ebay-scShare';
			if (d.getElementById(id)) {
				return;
			}
			js = d.createElement('script');
			js.id = id;
			js.async = true;
			js.defer = true;
			js.src = 'http://ir.ebaystatic.com/z/io/zvnlzbyj1a44peyfkapfzio1y.js';//"http://ir.qa.ebaystatic.com/z/ij/14wflfybny3pnejygcab00jqg.js";
			window.hideOverlay = false;
			d.getElementsByTagName('head')[0].appendChild(js);
			// Create chooseMoreBaseUrl (sopBaseUrl + soffid + sacat + sid + dmpt)
			var extractParamFromUrl = function(paramKey, url) {
				var param, params = url.slice(url.indexOf('?')+1).split('&');
				for (var i=0; i<params.length; i++) {
					param = params[i].split('=');
					if (param[0] === paramKey) {
						return param[1];
					}
				}
				return "";
			};
			var sopBaseUrl = $("#sopurl").val();
			var aspectFilterUrl = $("div.rlp div.asp-v a")[0].href;
			var soffid = extractParamFromUrl("_soffid", aspectFilterUrl);
			var saleid = extractParamFromUrl("_saleid", aspectFilterUrl);
			var sbunid = extractParamFromUrl("_sbunid", aspectFilterUrl);
			var sacat = extractParamFromUrl("_sacat", aspectFilterUrl);
			var sid = extractParamFromUrl("_sid", aspectFilterUrl);
			var dmpt = extractParamFromUrl("_dmpt", aspectFilterUrl);
			var sccid = extractParamFromUrl("_sccid", aspectFilterUrl);
			var chooseMoreBaseUrl = sopBaseUrl;
			if (soffid !== '') {
				chooseMoreBaseUrl += "?_soffid=" + soffid;
			} else if (saleid !== '') {
				chooseMoreBaseUrl += "?_saleid=" + saleid;
			} else if (sbunid !== '') {
				chooseMoreBaseUrl += "?_sbunid=" + sbunid;
			}
			if (sacat !== '') {
				chooseMoreBaseUrl += "&_sacat=" + sacat;	
			}
			if (sid !== '') {
				chooseMoreBaseUrl += "&_sid=" + sid;	
			}
			if (dmpt !== '') {
				chooseMoreBaseUrl += "&_dmpt=" + dmpt;	
			}
			if (sccid !== '') {
				chooseMoreBaseUrl += "&_sccid=" + sccid;	
			}
			$("#chooseMoreBaseUrl").val(chooseMoreBaseUrl);
			// Bypass overlay and redirect to VI (Only for iOS devices)
			$(".ic_wrop").live("hover", function() {
				var viUrl = $(this).find(".vilink a").attr("href");
				var iOS = /(iPad|iPhone|iPod)/g.test( navigator.userAgent );
				if (iOS === true) {
					window.location = viUrl + "&redirect=mobile";
				}
			});
			// Add to cart overlay initialization
			var atcOvlObj = {
				init: function(){
					var ol = atcOvlObj.oOlay = $('#atcOvlLaunch').ruiOverlay({"draggable": true});
					$('#atcOvlLaunch').on("click", $.proxy(atcOvlObj.open, atcOvlObj));
					ol.on("onshow", $.proxy(atcOvlObj.onShow, atcOvlObj));
					ol.on("onhide", $.proxy(atcOvlObj.onHide, atcOvlObj));
				},
				open: function(ev){
					$('#atcOvlLaunch').ruiOverlay('show',{data:{
						"content": $('#addtocart_ovl_placeholder'),
						"triggerId":ev.target.id
					}, options:{
						width: 700
					}});
				},
				onShow: function() {
					$('.oly-m').on("click", $.proxy(atcOvlObj.close, atcOvlObj));
				},
				onHide: function() {
					window.isSafeToOpenOvl = true;
					$('.oly-m').unbind("click");
				},
				close: function(ev){
					$('#atcOvlLaunch').ruiOverlay('hide');
				}
			};
			atcOvlObj.init();
			// Choose more overlay initialization
			var chooseMoreOvlObj = {
				init: function() {
					var ol = chooseMoreOvlObj.oOlay = $('#chooseMoreOvlLaunch').ruiOverlay({"draggable": true});
					$('#chooseMoreOvlLaunch').on("click", $.proxy(chooseMoreOvlObj.open, chooseMoreOvlObj));
				},
				open: function(ev) {
					$('#choose_more_ovl_placeholder').show();
					$('#chooseMoreOvlLaunch').ruiOverlay('show',{data:{
						"content": $('#choose_more_ovl_placeholder'),
						"triggerId":ev.target.id
					}, options:{
						width: 600
					}});
					$('.oly-m').on("click", $.proxy(chooseMoreOvlObj.close, chooseMoreOvlObj));
				},
				close: function(ev) {
					$('#chooseMoreOvlLaunch').ruiOverlay('hide');
				}
			};
			chooseMoreOvlObj.init();
			
			/*// Left navigation menu collapse click event
			$("div.rlp-h").on("click", function() {
				var parentEl = $(this).parent(); 
				if (parentEl.hasClass("collapse")) {
					parentEl.removeClass("collapse");
				} else {
					parentEl.addClass("collapse");
				}
			});*/
			
			// Other options click handler in choose more overlay
			// Make an AJAX call to load a set of new aspects for the selected option
			// If already loaded, show appropriate aspects and hide the old aspects
			$(document).on("click", "#choose_more_ovl_placeholder div.other a", function() {
				if (!$(this).hasClass("selected")) {
					var ajaxUrl = this.href;
					var title = $(this).html();
					$("div.other a.selected").removeClass("selected");
					$(this).addClass("selected");
					if ($("div.frame[title='" + title + "']").length > 0) {
						$("#choose_more_ovl_placeholder input[type='checkbox']").attr("id", "");
						$("div.frame:visible").hide();
						$("div.frame[title='" + title + "']").show();
						var chkbox = $("div.frame[title='" + title + "'] div.asf-v");
						for (var i=0; i<chkbox.length; i++) {
							var id = $(chkbox[i]).find("label").attr("for");
							$(chkbox[i]).find("input").attr("id", id);
						}
						$("#choose_more_ovl_placeholder div.wnd-t").html(title);
					} else {
						$.ajax({
							url: ajaxUrl,
							success: function(response) {
								$("#choose_more_ovl_placeholder input[type='checkbox']").attr("id", "");
								$("#choose_more_ovl_placeholder div.wnd-t").html(response.model.title);
								$("div.frame:visible").hide();
								var frameEl = $("<div class='frame' title='" + response.model.title + "'></div>");
								frameEl.html(response.content);
								$("td.frame").append(frameEl);
							},
							error: function(response) {
								console.log("Unable to show other option in the overlay.");
							}
						});	
					}	
				}
			});
			// Choose more overlay "cancel" button click handler
			// This closes the choose more overlay
			$("td.controls a.cancel").on("click", function() {
				$('#chooseMoreOvlLaunch').ruiOverlay('hide');
			});
			// Choose more overlay "Go" button click handler
			// Selected aspects are gathered, generate an url and redirect
			$("td.controls span.cm-button").on("click", function() {
				var queryStr = "";
				var chooseMoreBaseUrl = $("#chooseMoreBaseUrl").val();
				$('div.frame').each(function() {
					var encodedTitle = encodeURIComponent(encodeURIComponent($(this).attr("title")));
					var aspects = $(this).find('input:checked[type="checkbox"], input:checked[type="radio"], input[type="text"], input[type="hidden"], select');
					if (aspects.length > 0) {
						if (encodedTitle === "Preferences") {
							for(var i=0; i<aspects.length; i++) {
								var aspect = aspects[i]; 
								if (aspect.name === '_sadis' || aspect.name === '_fpos') {
									if ($("input[name='LH_Distance']:checked").val() === "1") {
										continue;
									}
								}
								queryStr += ("&" + aspects[i].name + "=" + encodeURIComponent(aspects[i].value)); 
							}
						} else {
							queryStr += ("&" + encodedTitle + "=");
							for(var i=0; i<aspects.length; i++) {
								queryStr += (encodeURIComponent(aspects[i].value) + "|");
							}
							queryStr = queryStr.substring(0, queryStr.length-1);
						}
					}
				});
				window.location = chooseMoreBaseUrl + queryStr;
			});
			// Choose more link click handler
			// Make an AJAX call to load the aspects on the overlay
			$("a.more").on("click", function() {
				var ajaxURL = $(this).attr("href");
				$.ajax({
					url: ajaxURL,
					success: function(response) {
						var content = response.content;
						var title = response.model.title;
						title = title !== null ? title : "Preferences";
						$("td.frame").html("");
						var frameEl = $("<div class='frame' title='" + title + "'></div>");
						frameEl.html(content);
						$("td.frame").append(frameEl);
						$("#choose_more_ovl_placeholder div.wnd-t").html(title);
						$("#choose_more_ovl_placeholder div.options").html("");
						
						if (title !== "Preferences") {
							$("td.options").show();
							$('a.more').each(function(){
								var href = decodeURIComponent(this.href);
								var ssanIdx = href.indexOf('_ssan=');
								var trimmedHref = href.substring(ssanIdx, href.length);
								var optionName = trimmedHref.substring(6, trimmedHref.indexOf('&'));
								if (optionName !== "LH_ShowOnly") {
									var otherDiv = $("<div class='other'><a onClick='return false;' href='" + this.href + "'>" + decodeURI(optionName) + "</a></div>");
									if (decodeURIComponent(optionName) === response.model.title) {
										otherDiv.find("a").addClass("selected");
									}
									$("#choose_more_ovl_placeholder div.options").append(otherDiv);
								}
							});
						} else {
							$("td.options").hide();
						}
						$("#chooseMoreOvlLaunch").click();
					},
					error: function(response) {
						console.log("Unable to show Choose More overlay.");
					}
				});
			});
			// Price range submit click event
			$("form[name='price'] input[type='button']").off("click");
			$("form[name='price'] input[type='button']").on("click", function() {
				var currentUrl = window.location.href;
			  	var min = $(this).siblings("input[name='_udlo']").val();
			  	var max = $(this).siblings("input[name='_udhi']").val();
			  	if ((min === "" && max === "") 
			  			|| (min !== "" && isNaN(min))
			  			|| (max !== "" && isNaN(max))) {
			  		$(this).siblings("div.enter-price").removeClass("g-hdn");
			  		return false;
			  	}
			  	window.location.href = currentUrl + "&_mPrRngCbx=1&_udlo=" + min + "&_udhi=" + max;
			});
			// Initialize zipcode overlay
			var zipcodeModule = require('search.layers.ZipCodeDialogInit');
			zipcodeModule.initOverlay();
			// Show overlay if sort by price + shipping
			var sortBy = extractParamFromUrl("_sop", document.location.href);
			if ((sortBy === '15' || sortBy === '16') && document.location.href.indexOf('_clu') === -1) {
				setTimeout(function() {$('span.sp_zc_unik').click();}, 10);
			}
			// Set share widget with seller logo image
			var logoImgSrc = $('div.logoimg > img').attr('src');
			logoImgSrc = logoImgSrc || 'http://ir.ebaystatic.com/f/n1mtb1y2221zzgii4rde3jnlnm1.jpeg';
			$('#sop-social-show').attr('data-imageurl', encodeURIComponent(logoImgSrc));
		}(document));
		
	