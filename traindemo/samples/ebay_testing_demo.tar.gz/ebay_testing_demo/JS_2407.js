	(function($win, urlScheme){
		"use strict";
		if(typeof $win !== "undefined" && typeof urlScheme !== "undefined"){
			$win.ebayAllowedUrlScheme = urlScheme;
		}
	}).call(this, window, {"startsWith":"https","endsWith":"ebay.com"});
	(function($win, headerKey, headerValue){
		"use strict";
		if(typeof $win !== "undefined" && typeof headerValue !== "undefined"){
			$win[headerKey] = headerValue;
		}
	}).call(this, window, 'correlation_session', 'ccdae9941540a78689624ff2fff92cf4');
