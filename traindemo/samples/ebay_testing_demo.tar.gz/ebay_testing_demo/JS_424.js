
(function() {
var Context = raptor.require('ebay.context.Context');
Context.call(Context,{"site":0,"errors":{"enabled":false},"app":"rguides","domain":".ebay.com","pool":"production","cobrand":2,"locale":"en_US_MAIN","features":{},"pid":2054849});
})();
 if(typeof GH!="undefined"&&GH){GH.urls={ autocomplete_js:"http://ir.ebaystatic.com/f/ol1e41pmee251bvjhybsauh5aaw.js",fnet_js:"https://c.paypal.com/webstatic/r/fb/fb-all-prod.akamai.pp2.min.js",ie8_js:"http://ir.ebaystatic.com/f/rbezfuzpu20wfd2kvejeb5adxyg.js",scandal_js:"http://ir.ebaystatic.com/f/wgp1j0iddmzdjjfgvr3dxrzz1i1.js" }; GH.GHSW={ raptor:"true",sandbox:0,emp:0,ac1:0,ac2:0,ac3:0,ac4:0,ac5:0,ac6:0,hideMobile:0,langSwitch:0,pool:0,ALERT_POPUPOFF:0,NEWALERT_POPUPOFF:0,newprofile:0,desktop_new_profile_service:"true" };} if(typeof GH!="undefined" && GH){GH_config={"siteId":"0","geoLang":"[]",sin:0,pageId:2054849,ct:0};GH.init();}
	(function() {
		var Csrf = raptor.require('ebay.secure.CsrfAjax');
		Csrf.call(Csrf);
	})();

		  window.fbAsyncInit = function() {
		    FB.init({appId: '102628213125203', 
		             status: true, 
		             cookie: true,
		         xfbml: true});
		
		    FB.api('/me', function(response) {
		      console.log(response.name);
		    });
		  };
		  (function() {
		    var e = document.createElement('script'); e.async = true;
		    e.src = document.location.protocol +
		      '//connect.facebook.net/en_US/all.js';
		    document.getElementById('fb-root').appendChild(e);
		  }());
		
		
				$(document).ready(function(){
				 $("[class^='filmstrip']").filmstrip();
				 <!-- $('.entry-image').imagefit(); -->
				 });
			
(function() {
var Context = raptor.require('ebay.context.Context');
Context.call(Context,{"site":0,"errors":{"enabled":false},"app":"rguides","domain":".ebay.com","cobrand":2,"pool":"production","locale":"en_US_MAIN","features":{},"pid":2054849});
})();
$rwidgets(['raptor.Guide.MultiScreen.ViewGuide','w1-1',{"isVisionQuestOn":false,"FBCommentsEnabled":true,"pageName":"ViewGuide","isYoutubeEmbedOn":true,"isEditorRedesignOn":false,"siteLang":"en_US_MAIN","editGuideURL":"http:\u002F\u002Fwww.ebay.com\u002Fgds\u002Fw.html?id=10000000178726132","isCaptionsRedesignOn":true,"viewItemIPadUrl":"padebay:\u002F\u002Flaunch?itm=","isEbayAuthor":true,"isStickyVotingOn":true,"isViewGuideRefreshOn":true,"guideOwner":"eBay","customTagImageUrl":"https:\u002F\u002Fcdn1.iconfinder.com\u002Fdata\u002Ficons\u002Fhawcons\u002F32\u002F698888-icon-145-tag-cord-24.png","isAndroid":false,"guideIdStr":"10000000178726132","guideURL":"http:\u002F\u002Fwww.ebay.com\u002Fgds\u002FHow-to-Use-a-Socket-Wrench-Set-\u002F10000000178726132\u002Fg.html","isViewGuideRedesignOn":true,"guideId":10000000178726132,"isImageTaggingEnabled":false,"pinterestEnabled":true},0,0,0,['raptor.guides.helpfulnessNew','w1-2',{"undoText":"Undo","signInUrl":"http:\u002F\u002Fsignin.ebay.com\u002Fws\u002FeBayISAPI.dll?SignIn&ru=http%3A%2F%2Fwww.ebay.com%2Fgds%2FHow-to-Use-a-Socket-Wrench-Set-%2F10000000178726132%2Fg.html","isTouchScreen":false,"votedAlreadyMsg":"You've already liked this Guide.","reportAlertMsg":"Are you sure you want to report this Guide?","isUserLoggedIn":false,"reportThanksMsg":"Thanks for reporting this Guide. We'll investigate.","isVotingRedesignOn":true,"reportAlreadyMsg":"You've already reported this Guide. Undo","isUnlikeVotingEnabled":true,"stickyGuidesInfoEnabled":true,"helpfulText":"Helpful","isMultiScreen":true,"voteTxt":"Like \u003Cb class=\"g-hdn\">if this guide is helpful\u003C\u002Fb>","unvoteTxt":"Liked","guideId":"10000000178726132","voteYesSuccessMsg":"Thanks! Your like has been counted.","reportLink":"http:\u002F\u002Fcgi3.ebay.com\u002Fws\u002FeBayISAPI.dll?ReportUserContentAbuse&contentId=10000000178726132","voteSignInMsg":"Please \u003Ca href=\"http:\u002F\u002Fsignin.ebay.com\u002Fws\u002FeBayISAPI.dll?SignIn&amp;ru=http%3A%2F%2Fwww.ebay.com%2Fgds%2FHow-to-Use-a-Socket-Wrench-Set-%2F10000000178726132%2Fg.html\">sign in\u003C\u002Fa> to like this Guide.","voteNoSuccessMsg":"We appreciate your honest feedback."}],['ui.Button','w1-3',{"id":"writeGuide"},'w1-1','writeGuide']],['raptor.Guide.SelectTemplate','w1-4',{"pageName":"ViewGuide","isViewGuideMultiScreenOn":true,"isEditorRedesignOn":true},0,0,0,['ui.Overlay','w1-5',{"id":"selTmpOly","trigger":"writeGuide,writeGuide1,writeGuide2,writeAnGuide","height":"320","width":"500","css3Enabled":true,"closeText":"close","modal":true,"closer":".guideOlyBtns a"},'w1-4','selTmpOly',0,['ui.radioButton','w1-6',{"id":"tmpSelection","name":"tid"},'w1-5','tmpSelection'],['ui.Button','w1-7',{"id":"selectTmp"},'w1-5','selectTmp'],['ui.Button','w1-8',{"id":"selectTmpCancel"},'w1-5','selectTmpCancel']]],['guides.tracking.PageScrollTracking','w1-9',{"relGdsTrackId":"p2054849.l5051","tagsTrackId":"p2054849.l5050"}]);new (raptor.require('raptor.tracking.core.Tracker'))({"psi":"A2JpVmTo*","rover":{"imp":"/roverimp/0/0/9","clk":"/roverclk/0/0/9","uri":"http://rover.ebay.com"},"pid":"p2054849"});raptor.require('raptor.tracking.idmap.IdMap').roverService("http://rover.ebay.com/idmap/0?footer");