
			var rtmUITrackerConfig = {"viewComplete":3,"viewInterval":500,"pageId":2047675,"deactivateAfter":600,"trackingEnabled":"true","samplingRate":100,"hoverMin":500};
		    var _plsubtInp = {"appId":"viewitem","eventFamily":"ADS","pageId":2047675,"disableImp":true,"env":"PROD"};
		    _plsubtInp.pageLoadTime = new Date().getTime();
		    _plsubtInp.samplingRate = rtmUITrackerConfig.samplingRate;
	        var _tq = [];
	    