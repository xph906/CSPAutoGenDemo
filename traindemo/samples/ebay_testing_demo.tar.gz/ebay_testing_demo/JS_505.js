
	if(typeof GH!="undefined"&&GH){GH.urls={
			autocomplete_js:"http://ir.ebaystatic.com/f/ol1e41pmee251bvjhybsauh5aaw.js",fnet_js:"https://c.paypal.com/webstatic/r/fb/fb-all-prod.akamai.pp2.min.js",ie8_js:"http://ir.ebaystatic.com/f/rbezfuzpu20wfd2kvejeb5adxyg.js",scandal_js:"http://ir.ebaystatic.com/f/wgp1j0iddmzdjjfgvr3dxrzz1i1.js"
		};
		GH.GHSW={
			raptor:0,sandbox:0,emp:0,ac1:0,ac2:0,ac3:0,ac4:0,ac5:0,ac6:0,hideMobile:0,langSwitch:0,pool:0,ALERT_POPUPOFF:0,NEWALERT_POPUPOFF:0,newprofile:0,desktop_new_profile_service:"true"
	};}
 