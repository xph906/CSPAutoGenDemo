
vjo.ctype("vjo.darwin.comp.utils.WindowDimension").props({D:undefined,getBrowserDimension:function(){var s=self;var d=document;var de=d.documentElement;if(s.innerHeight){return[s.innerWidth,s.innerHeight];}else if(de&&de.clientHeight){return[de.clientWidth,de.clientHeight];}
return[d.body.clientWidth,d.body.clientHeight];},getScrollXY:function(){var scrOfX=0,scrOfY=0,scrOfH=0,scrOfW=0,d=document.documentElement||document.body;if(typeof(window.pageYOffset)=='number'){return[window.pageXOffset,window.pageYOffset,document.height,document.width];}else if(d){return[d.scrollLeft,d.scrollTop,d.scrollHeight,d.scrollWidth];}
return[scrOfX,scrOfY,scrOfH,scrOfW];},getOffsetPosition:function(poElem){if(!poElem){return;}
var e=poElem,l=0,t=0,z=0,tz,h=e.offsetHeight,w=e.offsetWidth;while(e)
{l+=e.offsetLeft;t+=e.offsetTop;if(e.style){tz=parseInt(e.style.zIndex,10);z=!isNaN(tz)&&tz>z?tz:z;}
e=e.offsetParent;}
return[l,t,z,h,w];}}).endType();


vjo.ctype("vjo.darwin.comp.overlaypanel.ZIndexUtil").props({getNewZIndex:function(hasM,mzid,bzid,czid){if(!bzid&&!czid){return 0;}
var z=((hasM==false)?mzid:bzid);z=(czid&&czid>=z)?czid:z;return(z+10);}}).endType();


vjo.ctype("vjo.darwin.comp.overlaypanel.harrow.OverlayPanelWithHArrow").needs("vjo.darwin.comp.utils.WindowDimension").needs("vjo.dsf.Element","E").needs("vjo.darwin.comp.overlaypanel.ZIndexUtil","ZU").needs("vjo.dsf.client.Browser","B").protos({st:null,yof:0,aHW:null,pP:null,ar:null,preX:null,preY:null,IE:null,constructs:function(jsModel,bubble){var t=this;t.m=jsModel;var E=t.E=t.vj$.E;t.bbl=bubble;t.st=t.m.styles;t.yof=t.m.yof;t.aHW=t.m.arH;t.pP=t.m.pointPos;t.arrId=t.m.arrId;t.preX;t.preY;var b=t.vj$.B;t.IE=(b.bIE&&b.iVer<=6);t.aH=t.m.arH;t.aW=t.m.arW;t.os=t.m.OS;},W:vjo.darwin.comp.utils.WindowDimension,position:function(olp,refElem,halign,valign,overlayCompId,scrbl,scrlH,HOF,VOF,SIC,CID,HM,zid,mzid,oc,vns,CAT)
{var t=this,tp='top',b='bottom',r='right',l='left',u='px',ocS=oc.style,id=overlayCompId,scrbl=scrbl,scrlH=scrlH,z=0;var ofst=10,aHW=parseInt(t.aHW),hof=HOF;var aH=parseInt(t.aH);var aW=parseInt(t.aW);var yof=-aH;var xof=-aW;var P=t.P,olpS=olp.style,iW=olp.offsetWidth,iH=olp.offsetHeight,iZ=0;var W=t.W,wD=W.getBrowserDimension(),aS=W.getScrollXY();var finalX,finalY;t.ar=t.vj$.E.get(t.arrId);if(!t.ar){t.ar=document.createElement('div');t.ar.style.display='none';}
if(refElem)
{var rH=refElem.offsetHeight,pP=(t.pP=='CENTER')?(rH/2):((t.pP=='TOP')?0:rH),rW=refElem.offsetWidth,oP=W.getOffsetPosition(refElem),rX=oP[0],rY=oP[1]+pP,x=rX-aS[0],y=rY-aS[1],aX=0,aY=0,vAl=b,hAl;hof=hof+rW-xof;if(((iH<(wD[1]-y+aH))&&valign=='a')||(valign=='b'))
{finalY=(rY+yof);if(t.bbl)olpS.marginTop='-4px';}
else if(((iH<y)&&valign=='a')||(valign=='tp'))
{finalY=(rY-iH-yof);if(t.bbl)olpS.marginTop='-16px';vAl=tp;}
else
{finalY=((y<(wD[1]/2))?(y-30):(y-iH+ofst+30))+aS[1];if(t.bbl){finalY=finalY=(rY+yof);olpS.marginTop='-1px';}}
var iW=olp.offsetWidth;var rW=refElem.offsetWidth,rX=oP[0];var arS=t.ar.style;arS.display='';if((((iW+ofst+hof)<(wD[0]-x))&&halign=='a')||(halign=='l'))
{finalX=rX+hof;if(t.bbl)olpS.marginLeft='-24px';hAl=l;}
else if((((iW+ofst+hof)<x)&&halign=='a')||(halign=='r')){finalX=((rX+rW)-iW-hof)+20;if(t.bbl)olpS.marginLeft='22px';hAl=r;}
else{if(t.bbl){finalX=rX+hof;olpS.marginLeft='-22px';hAl=l;}else{finalX=(wD[0]-iW)/2+aS[0];if(vns!=-1)
finalY=(vns==0)?(rY+rH):(rY-iH-10);arS.display='none';}}
iZ=oP[2]?oP[2]:iZ;}
var tY=t.gAP(finalX,finalY,iW,iH,rX,rY,pP,rH,hAl,vAl);t.ar.className=t.gAS(hAl,vAl,t.st);arS.zIndex="999";if(vAl==tp){finalY=finalY-VOF;}else{finalY=finalY+VOF;}
if(olp.offsetParent){var offP=W.getOffsetPosition(olp.offsetParent);if(offP){finalX=finalX-offP[0];finalY=finalY-offP[1];}}
olpS.left=finalX+u;olpS.top=finalY+u;z=t.vj$.ZU.getNewZIndex(HM,zid,mzid,iZ);olpS.zIndex=z;if(valign!='b'){if(finalY<0){var tpStr=arS.top;var itp=parseInt(tpStr.replace('px',''));arS.top=itp+finalY+'px';olpS.top='0';}}
return[finalX,finalY,iW,iH,hAl,vAl,z];},gAP:function(oX,oY,oW,oH,rX,rY,pP,rH,hAl,vAl){var t=this,a=t.ar.style,yof=t.yof,u='px',la=17,ra=30,ta=22,oldaW=t.aW;if(t.aH<44&&!t.bbl){la=13;ta=16;ra=26;}
if(t.bbl){la=22;ra=29;}
a.position='absolute';a.top=(((rY-oY)>oH/2)?-5:0)+(rY-oY-ta)+u
if(t.bbl){a.top=((vAl=='top')?+12:0)+(rY-oY-ta)+u;}
if(rX<oX){a.left=-la+u;a.right='';}else{if(!t.bbl){t.aW=(t.aH<44)?27:31;}
if(t.bbl){a.top=((vAl=='top')?+11:0)+(rY-oY-ta)+u;}
a.right=-ra+u;a.left='';}
if(!t.bbl){a.height=t.aH+u;a.width=t.aW+u;}
t.aW=oldaW;},gAS:function(hAl,vAl,st){var bLeft=(hAl=='left')
if(vAl=='top'){return bLeft?st[1]:st[3];}else{return bLeft?st[0]:st[2];}}}).endType();


vjo.ctype('vjo.darwin.sharedpres.webcomponents.surveylink.SurveyHandler').needs('vjo.dsf.utils.UriBuilder').needs('vjo.dsf.Element').props({E:vjo.dsf.Element,onSurveyFormSubmit:function(windowName){var t=this;var width=800,height=800;var topMargin=Math.round((screen.height-height)/2);var leftMargin=Math.round((screen.width-width)/2);var windowFeature=["location=no","menubar=no","status=no","resizable=yes","scrollbars=yes"];windowFeature=windowFeature.concat(["top="+topMargin,"left="+leftMargin,"width="+width,"height="+height]);var newWindow=window.open("","Survey",windowFeature.join(","));return true;},onSurveyLinkClick:function(pBaseUrl,shouldPassDom,domFormId){var t=this;var pageUrl=document.location.href;var referrer=document.referrer;var redirectUrl=new vjo.dsf.utils.UriBuilder(pBaseUrl,false);redirectUrl.params.page=pageUrl;redirectUrl.params.referrer=referrer;var domForm=t.E.get(domFormId);if(shouldPassDom){var domContent=document.getElementsByTagName('html')[0].innerHTML;domContent="<html>"+domContent+"</html>";var domInputs=domForm.getElementsByTagName("input");domInputs[0].value=domContent;}
domForm.action=redirectUrl.getUri();domForm.submit();}}).endType();


vjo.ctype("vjo.darwin.comp.base.Base").needs("vjo.dsf.EventDispatcher",'ED').props({bodyLoaded:false}).inits(function(){this.vj$.ED.add("body","load",function(){if(!this.bodyLoaded)this.bodyLoaded=true;},this);}).endType();


vjo.ctype("vjo.darwin.comp.utils.EventUtils").needs("vjo.dsf.EventDispatcher",'ED').needs("vjo.darwin.comp.base.Base","B").needs('vjo.Registry','R').props({reg:{},add:function(cmpId,id,eventType,handler,scope){var rv=this.vj$.ED.add(id,eventType,handler,scope);if(id!="body"){this.register(cmpId,id,eventType);}
return rv;},register:function(cmpId,id,eventType){if(!cmpId||!id)return;this.reg[cmpId]=this.reg[cmpId]||{};var htmlIds,handlers=this.reg[cmpId];if(!handlers[eventType]){handlers[eventType]=[];}
handlers[eventType].push(id);},unRegister:function(cmpId,eventType){var evts=this.reg[cmpId];if(evts){evts=(eventType)?[evts[eventType]]:evts;for(var evtType in evts){var htmlIds=evts[evtType];for(var idx in htmlIds){this.vj$.ED.detachHandlers(htmlIds[idx],(eventType||evtType));}}}},callInit:function(elm,event,instanceId){var eType=(event)?event.type:null;if(eType=="mouseover"){elm.onmouseover=null;}else if(eType=="focus"){elm.onfocus=null;}
var obj=this.vj$.R.get(instanceId);if(obj)obj.init();},callOnLoad:function(jsInstanceIds){var t=this,f=function(){for(var i=0,l=jsInstanceIds.length;i<l;i++){var object=t.vj$.R.get(jsInstanceIds[i]);if(object&&object.onLoad)object.onLoad();}}
if(t.vj$.B.bodyLoaded)
f();else
t.add(null,"body","load",f,t);}}).inits(function(){vjo.dsf.EventDispatcher.addEventListener(window,'unload',function(){vjo.darwin.comp.utils.EventUtils.reg=null;});}).endType();


vjo.ctype("vjo.darwin.comp.utils.ServiceUtils").needs("vjo.dsf.ServiceEngine","SE").needs("vjo.dsf.Message","M").props({reg:[],rgSv:function(cmpId,svcId,handler){this.vj$.SE.registerSvcHdl(svcId,handler);this.register(svcId,cmpId);},rgSvRsp:function(cmpId,svcId,handler){this.vj$.SE.registerSvcRespHdl(svcId,handler);this.register(svcId,cmpId);},sndM:function(svcIdorMessage,jsonObject){return this.vj$.SE.handleRequest(typeof(svcIdorMessage)=="object"?svcIdorMessage:this.gM(svcIdorMessage,jsonObject));},gM:function(svcId,jsonObject){var msg=new this.vj$.M(svcId);msg.clientContext=jsonObject;return msg;},register:function(cmpId,svcId){if(!svcId||!cmpId)return;var SE=vjo.darwin.comp.utils.ServiceUtils;var svIds;if(!SE.reg[cmpId]){svIds=[];SE.reg[cmpId]=svIds;}else{svIds=(SE.reg[cmpId]);}
svIds.push(svcId)},unRegister:function(cmpId){var svcIds=this.reg[cmpId];if(svcIds)
for(var i=0,l=svcIds.length;i<l;i++){delete(vjo.dsf.ServiceEngine.inProcHdl.svcHdls[svcIds[i]]);}}}).endType();


vjo.ctype('vjo.darwin.comp.overlaypanel.OverlayAccessibilityUtil').needs("vjo.dsf.Element").needs("vjo.darwin.comp.utils.EventUtils").needs("vjo.darwin.comp.utils.ServiceUtils","SE").props({E:vjo.dsf.Element,EU:vjo.darwin.comp.utils.EventUtils,SE:vjo.darwin.comp.utils.ServiceUtils,createAnchors:function(OP){var t=this;var O=OP;var I=O.cmpId,inWr=t.E.get(I+'olp-pad'),tp=t.E.get(I+'_tpDiv');O.sA=t.E.get(O.i.sa);O.eA=t.E.get(O.i.ea);if(O.sA&&O.eA){if(O.f.TS){O.fTd.appendChild(O.sA);O.lTd.appendChild(O.eA);}
else if(inWr){inWr.insertBefore(O.sA,tp);inWr.appendChild(O.eA);}
t.EU.add(O.cmpId,O.eA.id,'focus',function(){t.hide(O);},O);}
var clsBtn=t.E.get(O.i.cb);if(clsBtn){t.SE.rgSv(O.cmpId,O.i.cb+'_cBSv',function(){t.hide(O);},O);}},hide:function(O){var t=this;try{if(O.nfe||O.refE){O.skip=true;(O.nfe||O.refE).focus();}
if(O.Open)O.close();}catch(e){O.skip=false;}
O.skip=false;}}).endType();


vjo.ctype('vjo.darwin.comp.overlaypanel.OverlayPanel').needs("vjo.dsf.client.Browser","B").needs("vjo.dsf.Element","E").needs("vjo.dsf.document.Shim","S").needs("vjo.darwin.comp.utils.EventUtils","EU").needs("vjo.dsf.EventDispatcher","EV").needs("vjo.darwin.comp.utils.ServiceUtils","SE").needs('vjo.Registry',"R").needs('vjo.darwin.comp.overlaypanel.OverlayAccessibilityUtil','OU').protos({aId:null,sA:null,eA:null,skip:false,nfe:null,cntDiv:null,lTd:null,fTd:null,constructs:function(jsmdl,props){var t=this,J=t.vj$,B,p=props,M1=jsmdl,E=J.E,I=p.id;t.cmpId=p.id;t.OID=p.OId;t.J=J;t.m=p;t.m1=jsmdl;t.Open=false;t.cusPos=null;t.cW=p.CW;t.mst=-1;t.st=null;t.fCall=false;t.getS();t.dmProps();t.mW=t.m1.MW;t.nfe=J.E.get(M1.NFEI);var f1=function(m){if(!t.olp){t.create();}
t.open(m);},f2=function(m){t.close(m);};J.SE.rgSv(t.cmpId,t.i.o+p.id,f1);J.SE.rgSv(t.cmpId,t.i.c+p.id,f2);},rePos:function(t){if(!t)t=this;if(t.Open&&(t.refE||t.f.SIC)){t.posPanel(t.olp,t.refE);}},open:function(msg){var t=this;if(t.m1.AT&&t.skip){t.skip=false;return;}
var f=function(){t.olp.style.visibility="visible";t.Open=true;t.refE=t.J.E.get(msg.sAnchorId);t.posPanel(t.olp,t.J.E.get(msg.sAnchorId));if(t.sA&&t.olp.offsetWidth>0){try{t.sA.focus();}catch(ex){};}
t.J.SE.sndM(t.i.po+t.cmpId);};if(t.f.HM){var mskM=t.J.SE.gM(t.m1.MCO);mskM.containerId=t.sId;t.J.SE.sndM(mskM);}
(!t.fCall)?t.regEvt():'';t.ST(t.cntDiv,t.m.CH);clearTimeout(t.st);t.st=setTimeout(f,t.od||0);},create:function(){var t=this,p=t.m;var wrapper,leftSpace,topSpace,st,cntDiv,c2,cnt;if(t.f.TS)
wrapper=(t.os=='2')?t.CE('table','ov-w ov-sm'):t.CE('table','ov-w '+(t.m.opt.CN||''));else
wrapper=(t.os=='2')?t.CD('ov-w ov-sm'):t.CD('ov-w '+(t.m.opt.CN||''));wrapper.id=p.id;wrapper.style.position="absolute";leftSpace=t.CE('b','');topSpace=t.CE('i','');if(t.f.TS)
{wrapper.cellSpacing='0';wrapper.cellPadding='0';var tbody=t.CE('tbody','');var topTr=t.CE('tr','');var topTd=t.CE('td','ov-t');topTr.appendChild(topTd).appendChild(leftSpace).appendChild(topSpace);tbody.appendChild(topTr);t.fTd=topTd;}
else
{var innerWrapper=t.CD('ov-fl');innerWrapper.id=t.m.id+"olp-pad";wrapper.appendChild(innerWrapper);var topDiv=t.CD('ov-t');topDiv.id=t.cmpId+'_tpDiv';innerWrapper.appendChild(topDiv).appendChild(leftSpace).appendChild(topSpace);}
st=["20","15","10"];cntDiv=(t.f.PO)?t.CD('ov-cnt ov-p'+st[t.os]):t.CD('ov-cnt ov-p0');t.ST(cntDiv,p.CH,p.CW);cntDiv.id='cntw'+p.id;c2=t.CD('ov-c2');cnt=t.J.E.get(t.m.cnId);var b=t.CE('b',''),i=t.CE('i','');if(t.f.TS)
{var cntTr=t.CE('tr','');var cntTd=t.CE('td','ov-c1');cntTr.appendChild(cntTd).appendChild(c2).appendChild(cntDiv);tbody.appendChild(cntTr);var footTr=t.CE('tr','');var footTd=t.CE('td','ov-b');t.lTd=footTd;var lastElemId=t.cmpId+'last';i.id=lastElemId;footTr.appendChild(footTd).appendChild(b).appendChild(i);tbody.appendChild(footTr);wrapper.appendChild(tbody);}
else
{var d5=t.CD('ov-b');var midDiv=t.CD('ov-c1');innerWrapper.appendChild(midDiv).appendChild(c2).appendChild(cntDiv);innerWrapper.appendChild(t.CE('u','ov-clr'));innerWrapper.appendChild(d5).appendChild(b).appendChild(i);}
cntDiv.appendChild(cnt);if(t.f.cbtn){var close;if(t.os==0){close=t.CE('a','ov-cl');}else{close=t.CE('a','ov-cl-m');}
var hTxt=t.CE('b','g-hdn');hTxt.innerHTML=t.m1.cbTxt;close.id=t.i.cb;close.href="javascript:;"
if(hTxt)close.appendChild(hTxt);cntDiv.appendChild(close);}
if(t.f.ptr){var ptr=t.CE('b','');ptr.id=t.i.arrId;cntDiv.appendChild(ptr);}
if(t.f.p2b){document.body.appendChild(wrapper);}else{var cmp=t.vj$.E.get(t.OID);cmp.parentNode.insertBefore(wrapper,cmp);}
var hide=function(msg){if(t.m1.AT){msg=t.J.SE.gM(t.i.cb+'_cBSv');msg.clsBtn=true;}
t.close(msg);}
if(t.f.cbtn)
t.vj$.EU.add(t.cmpId,t.i.cb,"click",function(msg){hide(msg);},t);t.olp=wrapper;if(t.f.DG||t.f.HD){var js=t.vj$.R.get(t.i.djs);if(js)
js.regDrag();}
if(t.m1.AT){t.J.OU.createAnchors(t);}
if(t.f.COM){var fin=function(){t.onMin()};t.vj$.EU.add(t.cmpId,t.m.id,"mouseover",function(){t.setMState(1)},t);t.vj$.EU.add(t.cmpId,t.m.id,"mouseout",function(){t.setMState(0)},t);t.vj$.EU.add(t.cmpId,t.cmpId,"mouseover",fin,t);t.vj$.EU.add(t.cmpId,t.m.id,"mouseout",function(e){t.onMout(e)},t);}
var outWr=t.vj$.E.get(t.m.OId);outWr.style.display='none';},dmProps:function(){var t=this;t.mp=t.m.opt;if(t.mp.JS){}
if(!t.mp.VF){t.mp.VF=0;}
if(!t.mp.HF){t.mp.HF=0;}
t.ha=t.mp.HA;t.va=t.mp.VA;t.cd=t.mp.CD;t.od=t.mp.OD;t.vns=t.mp.VNS;t.os=t.mp.OS;var num=t.m.m1;t.f={};t.f.srbl=t.i2B(num,0);t.f.cbtn=t.i2B(num,1);t.f.COM=t.i2B(num,2);t.f.COB=t.i2B(num,3);t.f.STK=t.i2B(num,4);t.f.DG=t.i2B(num,5);t.f.SIC=t.i2B(num,6);t.f.HM=t.i2B(num,7);t.f.ptr=t.i2B(num,8);t.f.CL=t.i2B(num,9);t.f.p2b=t.i2B(num,10);t.f.CAT=t.i2B(num,11);t.f.HD=t.i2B(num,12);t.f.PO=t.i2B(num,13);t.f.FX=t.i2B(num,14);t.f.TS=t.i2B(num,15);t.f.COT=t.i2B(num,16);},getS:function(){var t=this,M1=t.m1;var s=M1.suffixes;t.i={};t.i.o=s[0];t.i.c=s[1];t.i.po=s[2];t.i.pc=s[3];t.i.cb=t.cmpId+s[4];t.i.djs=t.cmpId+s[5];t.i.arrId=t.m.id+"arid";t.i.sa=t.cmpId+s[6];t.i.ea=t.cmpId+s[7];},CD:function(cls){var t=this;return t.CE('div',cls);},CE:function(elm,cls){var e=document.createElement(elm);if(cls!=''){e.className=cls;}
return e;},ST:function(elm,ht,wd,vis){if(!elm)return;if(typeof(ht)!='undefined')elm.style.height=(ht==0)?"auto":ht+"px";if(typeof(wd)!='undefined')elm.style.width=(wd==0)?"auto":wd+"px";if(this.mW>0)
elm.style.maxWidth=this.mW+'px';if(vis)
elm.style.visibility=vis;return elm;},i2B:function(num,idx){var val=num.toString(2),l=val.length-1,ds=(idx-l)<0?-(idx-l):(idx-l);if(idx>=val.length){return false;}
return(val.charAt(ds)==1);},posPanel:function(olp,refElem){var u='px',t=this,m=t.m;var fl1=t.J.E.get("olp-pad");var cntDv=t.J.E.get('cntw'+t.m.id);var h=vjo.Registry.get(t.mp.JS);if(!h){return;}
var p=h.position(t.olp,refElem,t.ha,t.va,t.cmpId,t.f.srbl,t.mp.SH,t.mp.HF,t.mp.VF,t.f.SIC,null,t.f.HM,t.m.z,t.m.mz,cntDv,t.vns,t.f.CAT,t.f.FX);},close:function(message){var t=this,f=function(){if(!t.olp)return;var s=t.olp.style;s.visibility='hidden';s.left="-9999px";t.Open=false;t.ST(t.cntDiv,0);var isRetire=(message&&message.isRetire);if(!isRetire){t.J.SE.sndM(t.i.pc+t.cmpId);if(t.f.HM)
t.J.SE.sndM(t.m1.MCI);}
if(message&&message.clsBtn){t.J.SE.sndM(t.i.cb+'_cBSv');}};if(t.f.COT)
clearTimeout(t.st);t.J.SE.sndM('PRC'+t.cmpId);clearTimeout(t.ct);t.ct=setTimeout(f,(message&&message.ignDelay)?0:t.cd);},setMState:function(state){this.mst=state;},onMout:function(evt){var t=this,e=evt.nativeEvent,pEle=e.toElement||e.relatedTarget;if(!t.f.COM||(t.olp&&t.J.E.containsElement(t.olp,pEle))){return;}
t.close();},onMin:function(){if(this.f.COM)
clearTimeout(this.ct);},onResize:function(t){if(!t)t=this;if(t.Open&&(t.refE||t.f.SIC)){t.posPanel(t.olp,t.refE);}},regEvt:function(){var t=this,rF=function(){t.onResize(t);};if(!t.f.STK&&!t.f.FX){t.rgEH('resize',rF);t.rgEH('scroll',rF);}
var f1=function(e){if(!t.Open)return;var el=e.nativeEvent.srcElement||e.nativeEvent.target;if(!t.f.COB)
return;while(el){if(el.id==t.cmpId||(t.refE&&t.refE.id==el.id)){return;}
el=el.parentNode;}
t.close();};t.vj$.EU.add(t.cmpId,'body','click',f1,t);t.fCall=true;},rgEH:function(evt,hnd){this.J.EV.addEventListener(window,evt,hnd,window);}}).props({olps:[],olpMsg:function(messageId,anchorId,cnt,model,ho,delay){var o=this.vj$.SE,m=o.gM(messageId);m.sAnchorId=anchorId;if(cnt)m.cnt=cnt;if(model)m.model=model;if(ho!=null)m.ho=ho;if(delay!=null)m.ignDelay=delay;o.sndM(m);},closeOverlays:function(onlyOnBodyClick){var olp=vjo.darwin.comp.overlaypanel.OverlayPanel;for(var i=0;i<olp.olps.length;i++){if(olp.olps[i]&&(!onlyOnBodyClick||olp.olps[i].f.COB)){olp.olps[i].close();}}},sendMessage:function(svcId,model){this.olpMsg(svcId,model.anchorId,model.cnt,model);},registerEvent:function(model,openServiceId,closeServiceId,openEvent,closeEvent){var t=this,handler=vjo.dsf.EventDispatcher,f1=function(){t.sendMessage(openServiceId,model)},f2=function(){t.sendMessage(closeServiceId,model)};handler.add(model.anchorId,openEvent,f1,t);handler.add(model.anchorId,closeEvent,f2,t);}}).endType();


