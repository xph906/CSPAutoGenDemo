
        scandal.init();
        scandal.callGPT(
                "scandal100615",
                {"targetingParameters":{"ap":"Scandal","cat":[],"us":"13","ot":"1","kw":"sporting-goods","pr":"20","xp":"20","np":"20","u":"51b136f5d29e486cb75d1047f0da3419"},"fallbackContent":null,"fallback":false,"pageId":2051541,"placementId":100615,"providerParameters":{"size":{"height":90,"width":970},"networkId":"6245","adUnitId":"ebay.ebayus.rpp"}},
                "default",
                false
        );
    