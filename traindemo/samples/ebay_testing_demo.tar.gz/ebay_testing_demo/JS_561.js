(function(){
	var sortByModule = raptor.require("search.controlBar.SortBy"); 
	sortByModule.init({'elem':'e1-7','select':'e1-7_s','href':'http://www.ebay.com/sme/backcountry/free%2B2-day%2Bshipping%2Bon%2Borders%2B%2450%2B/so.html?_sofftype=promotionalshipping&_soffid=5015172703&_seedid=551153401498&_ipg=200&_sacat=159136&_sid=2048038','links':[{'href':'_sop=1'},{'href':'_sop=10'},{'href':'_sop=15'},{'href':'_sop=16'},{'href':'_sop=3'},{'href':'_sop=7'},{'href':'_sop=12'},null]});
})();