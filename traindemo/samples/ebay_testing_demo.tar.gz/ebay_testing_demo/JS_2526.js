(function(){
	var sortByModule = raptor.require("search.controlBar.SortBy"); 
	sortByModule.init({'elem':'e1-4','select':'e1-4_s','href':'http://www.ebay.com/sme/easternmountainsports/save%2Bup%2Bto%2B25%25/so.html?_sofftype=saleevent&_seedid=570930166067&_saleid=5012487606&_sid=2048038','links':[{'href':'_sop=1'},{'href':'_sop=10'},{'href':'_sop=15'},{'href':'_sop=16'},{'href':'_sop=3'},{'href':'_sop=7'},{'href':'_sop=12'},null]});
})();