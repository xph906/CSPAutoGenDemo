
vjo.ctype("vjo.dsf.FirePageLoad").endType();if(typeof(oGaugeInfo)!="undefined"){oGaugeInfo.iLoadST=(new Date()).getTime();}
vjo.dsf.EventDispatcher.load(document.body);

