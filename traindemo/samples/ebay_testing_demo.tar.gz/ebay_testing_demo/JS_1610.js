
		function getElementsByClassName(e,t){var n=[];var r=new RegExp("(^| )"+t+"( |$)");var i=e.getElementsByTagName("*");for(var s=0,o=i.length;s<o;s++)if(r.test(i[s].className))n.push(i[s]);return n}			
	